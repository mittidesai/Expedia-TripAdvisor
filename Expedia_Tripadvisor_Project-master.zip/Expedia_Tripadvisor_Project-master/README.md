# Expedia_Tripadvisor_Project
Final project for Python
